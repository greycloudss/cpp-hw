#include <iostream>
#include <stdio.h>
#include <stdlib.h>


int main(void) {
	std::cout << "Hello world!" << std::endl;
	return 0;
}